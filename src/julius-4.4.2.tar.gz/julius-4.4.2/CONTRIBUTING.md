To get started, <a href="https://www.clahub.com/agreements/julius-speech/julius">sign the Contributor License Agreement</a>.
