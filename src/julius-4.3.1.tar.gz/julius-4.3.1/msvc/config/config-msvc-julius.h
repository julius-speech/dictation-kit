/* config.h.  Generated automatically by configure.  */
/* Define if you use character conversion function */
#define CHARACTER_CONVERSION 1

/* Define if you use Win32 character conversion API */
#define USE_WIN32_MULTIBYTE 1

/* Define if you have iconv function */
// #undef HAVE_ICONV

/* Define if you have const char prototype in iconv function */
// #define ICONV_CONST const

/* Define if you use libjcode */
#define USE_LIBJCODE
